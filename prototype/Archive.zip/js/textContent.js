/*!
 * classie - class helper functions
 * from bonzo https://github.com/ded/bonzo
 * 
 * classie.has( elem, 'my-class' ) -> true/false
 * classie.add( elem, 'my-new-class' )
 * classie.remove( elem, 'my-unwanted-class' )
 * classie.toggle( elem, 'my-class' )
 */

/*jshint browser: true, strict: true, undef: true */
/*global define: false */

( function( window ) {
 $.ajax({
          url: "getTextContent.php",
          type: "GET",
          dataType: "json",
          success: function (response) {
            staticText(response);
          },
          error: function(response) {
              console.log(response);
              console.log('Test failed!');                  
          }
      }); 
})( window );
